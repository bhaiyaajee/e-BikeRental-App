package com.example.logindemo;

public class UserProfile
{
    public String Name;
    public String Email;
    public String Phone;
    public String Password;

       public UserProfile(String Name , String Email , String Phone, String Password)
{
    this.Name= Name;
    this.Email=Email;
    this.Phone=Phone;
    this.Password=Password;
}
}
