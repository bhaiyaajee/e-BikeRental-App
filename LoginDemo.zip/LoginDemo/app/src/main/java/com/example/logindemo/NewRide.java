package com.example.logindemo;

public class NewRide {
    public String UID;
    public String Date;
    public String PickUpLoc;
    public String Time;

    public NewRide(String UID, String date, String pickUpLoc, String time) {
        this.UID = UID;
        this.Date = date;
        this.PickUpLoc = pickUpLoc;
        this.Time = time;
    }
}
